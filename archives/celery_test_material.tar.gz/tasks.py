from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
from celery import Celery
# from run_spider_in_celerey import AdstxtCrawlerScript
# from adstxt.spiders.adstxt_spider import AdstxtSpider

app = Celery("tasks",
            backend = "rpc://",
            broker = "amqp://adstxt:rockoholic@localhost:5672/adstxtcrawler")

# @app.task
# def crawl_this(fileInfo):
#     process = CrawlerProcess(get_project_settings())
#     process.crawl('adstxt', fileInfo=fileInfo)
#     process.start(stop_after_crawl=False)
#     process.join()
#     process.stop()
#     return True

# @app.task
# def run_spider(fileInfo):
#     spider = AdstxtSpider(fileInfo)
#     crawler = AdstxtCrawlerScript(spider)
#     crawler.start()
#     crawler.join()

@app.task
def add_these(a,b):
    return a + b
